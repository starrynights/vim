Pyflakes
==========

This is just a manual dump of the vim pyflakes plugin from:
http://www.vim.org/scripts/script.php?script_id=2441

The purpose is to try to make this compatible with pathogen plugin. So creating
the dir structure and hopefully this means we can just keep the norm and git
clone the repo into the bundle directory and things will load up magically.


